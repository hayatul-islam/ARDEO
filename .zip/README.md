# ARDEO

[Project Demo](https://ardeo.netlify.app/).

## Features:

- Registration and Login with local storage.
- Application state management with Redux Toolkit
- Fully responsive with Tailwind CSS

## Technology used: React, Redux, Tailwind CSS, Local storage
